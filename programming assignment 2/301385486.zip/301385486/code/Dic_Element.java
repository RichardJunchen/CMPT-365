
public class Dic_Element {
    private final int code;
    private final String element;


    public int getCode() {
        return code;
    }


    public String getElement() {
        return element;
    }

    public Dic_Element( int code, String element) {
        this.code = code;
        this.element = element;
    }




}
